from flask import Flask, render_template, Response, request, jsonify, send_from_directory
import cv2
import os
import numpy as np
from datetime import datetime
from modules.ocr import extract_number_plate_text
from modules.database import save_data_to_csv
from modules.alerts import alert_system

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
SUSPICIOUS_FOLDER = 'suspicious_images'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(SUSPICIOUS_FOLDER, exist_ok=True)

plate_cascade = cv2.CascadeClassifier("haarcascade_russian_plate_number.xml")
video_path = None
camera = None
mode = None
suspicious_detected = {}
latest_suspicious_image = ""

def detect_number_plate(frame):
    global suspicious_detected, latest_suspicious_image
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    plates = plate_cascade.detectMultiScale(gray, 1.1, 4)
    for (x, y, w, h) in plates:
        area = w * h
        if area > 500:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
            img_roi = frame[y:y + h, x:x + w]
            detected_text = extract_number_plate_text(img_roi)
            if detected_text:
                save_data_to_csv(detected_text)
                alert_system(detected_text)
                if detected_text in ["GJO3ER0563", "2TC0204", "GJOSEROSES", "KAG2NP96571"]:
                    if detected_text not in suspicious_detected:
                        suspicious_detected[detected_text] = 0
                    if suspicious_detected[detected_text] < 3:
                        suspicious_detected[detected_text] += 1
                        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                        latest_suspicious_image = f"{detected_text}_{timestamp}.jpg"
                        cv2.imwrite(os.path.join(SUSPICIOUS_FOLDER, latest_suspicious_image), img_roi)
    return frame

def generate_frames(source):
    cap = cv2.VideoCapture(source)
    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break
        frame = detect_number_plate(frame)
        _, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()
        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    cap.release()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/set_mode', methods=['POST'])
def set_mode():
    global mode
    data = request.json
    mode = data.get("mode")
    return jsonify({'message': f'Mode set to {mode}'})

@app.route('/video_feed')
def video_feed():
    global video_path, mode
    if mode == "video" and video_path:
        return Response(generate_frames(video_path), mimetype='multipart/x-mixed-replace; boundary=frame')
    return jsonify({'error': 'Video mode not selected'})

@app.route('/webcam_feed')
def webcam_feed():
    if mode == "camera":
        return Response(generate_frames(0), mimetype='multipart/x-mixed-replace; boundary=frame')
    return jsonify({'error': 'Camera mode not selected'})

@app.route('/upload_video', methods=['POST'])
def upload_video():
    global video_path, mode
    if 'file' not in request.files:
        return jsonify({'error': 'No video file uploaded'})
    file = request.files['file']
    video_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(video_path)
    return jsonify({'message': 'Video uploaded successfully', 'video_path': video_path})

@app.route('/check_suspicious')
def check_suspicious():
    global latest_suspicious_image
    if latest_suspicious_image:
        return jsonify({'alert': True, 'image': f'/get_suspicious_image/{latest_suspicious_image}'})
    return jsonify({'alert': False})

@app.route('/get_suspicious_image/<filename>')
def get_suspicious_image(filename):
    return send_from_directory(SUSPICIOUS_FOLDER, filename)

if __name__ == '__main__':
    app.run(debug=True)
