import cv2
import os
import subprocess
from modules.ocr import extract_number_plate_text
from modules.database import save_data_to_csv
from modules.alerts import alert_system

# ------------------- USER INPUT -------------------
mode = input("Enter mode (video/camera): ").strip().lower()

if mode == "video":
    video_path = input("Enter video file path (e.g., 'your_video.mp4'): ").strip().strip('"')
    if not os.path.exists(video_path):
        print(f"❌ Error: Video '{video_path}' not found!")
        exit()
    save_folder = "videos"

elif mode == "camera":
    camera_type = input("Select Camera Type (webcam/image): ").strip().lower()
    
    if camera_type == "webcam":
        cap = cv2.VideoCapture(0)
        cap.set(3, 1000)
        cap.set(4, 480)
        cap.set(10, 150)
        save_folder = "images"

    elif camera_type == "image":
        image_path = input("Enter image file path (e.g., 'car.jpg'): ").strip().strip('"')
        if not os.path.exists(image_path):
            print(f"❌ Error: Image '{image_path}' not found!")
            exit()
        
        # Load Image and Run OCR Directly
        img = cv2.imread(image_path)
        cv2.imshow("Input Image", img)
        
        detected_text = extract_number_plate_text(img)
        if detected_text:
            print("\n" + "="*40)
            print(f"✅ Detected Plate: {detected_text}")
            print(f"📄 Data Saved in CSV: {detected_text}")
            print("="*40 + "\n")
            save_data_to_csv(detected_text)
            alert_system(detected_text)
        else:
            print("\n Text detected on the plate & images are saved in respected folder..\n")
        
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        exit()  # Exit after processing the image

    else:
        print("❌ Invalid input! Please enter 'webcam' or 'image'.")
        exit()

else:
    print("❌ Invalid input! Enter 'video', 'camera', or 'image'.")
    exit()

# Haarcascade for Number Plate Detection
plateCascade = cv2.CascadeClassifier("haarcascade_russian_plate_number.xml")
os.makedirs(save_folder, exist_ok=True)

count = 0
while True:
    if mode == "video":
        cap = cv2.VideoCapture(video_path)

    while True:
        success, img = cap.read()
        if not success:
            print("🎬 Video Ended!")
            break

        imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        numberPlates = plateCascade.detectMultiScale(imgGray, 1.1, 4)

        for (x, y, w, h) in numberPlates:
            area = w * h
            if area > 500:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                cv2.putText(img, "Number Plate", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
                imgRoi = img[y:y + h, x:x + w]
                cv2.imshow("Number Plate", imgRoi)

        cv2.imshow("Video Stream" if mode == "video" else "Camera Feed", img)

        key = cv2.waitKey(1)
        if key == ord('s'):
            filename = f"./{save_folder}/{str(count)}.jpg"
            cv2.imwrite(filename, imgRoi)

            # 🔹 OCR: Extract Number Plate Text
            detected_text = extract_number_plate_text(imgRoi)

            if detected_text:
                print("\n" + "="*40)
                print(f"✅ Detected Plate: {detected_text}")
                print(f"📄 Data Saved in CSV: {detected_text}")
                print("="*40 + "\n")
                save_data_to_csv(detected_text)  # Always save in CSV
                alert_system(detected_text)
            else:
                print("")
            count += 1

        if key == ord('o'):
            subprocess.run(f'explorer {os.path.abspath(save_folder)}', shell=True)

        if key == ord('q'):
            print("👋 Exiting...")
            cap.release()
            cv2.destroyAllWindows()
            exit()
