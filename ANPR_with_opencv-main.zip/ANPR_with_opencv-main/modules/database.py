# 📌 Import Libraries
import csv
import os

# 📌 CSV File Path
csv_file = "data/detected_plates.csv"

# 📌 Ensure 'data' folder exists
os.makedirs("data", exist_ok=True)

# 📌 Function to Save Data in CSV
def save_data_to_csv(plate_text):
    """Save detected number plate text into CSV file."""
    with open(csv_file, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([plate_text])
    print(f"📄 Data Saved in CSV: {plate_text}")
