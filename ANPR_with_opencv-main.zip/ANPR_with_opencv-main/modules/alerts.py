import winsound  # Beep sound ke liye (Windows)
from plyer import notification  # Desktop notification ke liye

# Suspicious Number Plates List
alert_list = ["GJO3ER0563","2TC0204","GJOSEROSES","KAG2NP96571"]  # Yahan apni list update karenge suspected cars ki 

# Alert Function
def alert_system(plate_text):
    """Agar plate suspicious hai, to sound aur notification trigger karega."""
    if plate_text in alert_list:
        print(f"🚨 ALERT! Suspicious Vehicle Detected: {plate_text}")

        try:
            # 🔊 Beep Sound (Only for Windows)
            winsound.Beep(1000, 500)  
        except Exception as e:
            print(f"⚠️ Beep Sound Error: {e}")

        try:
            # 💬 Desktop Notification
            notification.notify(
                title="🚨 Suspicious Vehicle Alert!",
                message=f"Vehicle: {plate_text}",
                timeout=15
            )
        except Exception as e:
            print(f"⚠️ Notification Error: {e}")
