import cv2
import pytesseract
import numpy as np

# Set correct path for Tesseract
pytesseract.pytesseract.tesseract_cmd = r'C:\Users\katta\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'

def preprocess_image(image):
    """
    Preprocess the image to enhance OCR accuracy.
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Enhance contrast and remove noise
    gray = cv2.GaussianBlur(gray, (3, 3), 0)
    gray = cv2.equalizeHist(gray)

    # Apply Adaptive Thresholding
    thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                   cv2.THRESH_BINARY, 11, 2)

    # Morphological Operations to clean up noise
    kernel = np.ones((2,2), np.uint8)
    processed_img = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    return processed_img

def extract_number_plate_text(image):
    """
    Extracts only black-colored text from the processed image using Tesseract OCR.
    """
    processed_img = preprocess_image(image)

    # Define custom OCR configurations
    custom_config = r'--oem 3 --psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    text = pytesseract.image_to_string(processed_img, config=custom_config)

    # Clean text by removing unwanted characters
    extracted_text = "".join(filter(str.isalnum, text))
    return extracted_text

if __name__ == "__main__":
    image_path = input("Enter image file path: ")
    img = cv2.imread(image_path)
    
    detected_text = extract_number_plate_text(img)
    
    if detected_text:
        print(f"✅ Extracted Number Plate Text: {detected_text}")
        with open("output.csv", "a") as f:
            f.write(f"{detected_text}\n")
    else:
        print(" Text detected on plate.")
